$(document).ready(function () {

    //datatable
    $("#example").DataTable();
});
